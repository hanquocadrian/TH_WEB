<ul>
	<li><a href="index.php" class="current">Home</a></li>
	<li><a href="subpage.html">Search</a></li>
	<li><a href="subpage.html">Books</a></li>
	<li><a href="subpage.html">New Releases</a></li>
	<li><a href="#">Company</a></li>
	<li><a href="#">Contact</a></li>
</ul>