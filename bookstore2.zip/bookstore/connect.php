<?php
$obj = new PDO("mysql:host=localhost; dbname=abcd"   ,  'root'  , '' );//mysqli
$obj->query('set names utf8');