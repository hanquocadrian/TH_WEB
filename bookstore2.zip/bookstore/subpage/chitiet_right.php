<?php
    $masach = $_GET['masach'];
    $tam= $obj->query("select * from sach where masach='$masach' ");
    $data = $tam->fetch();
?>
<h1><?php echo $data['tensach'] ?></span></h1>
<div class="image_panel"><img src="images/image_data/<?php echo $data['hinh'] ?>" alt="CSS Template" width="100" height="150" /></div>
<h2>Read the lessons - Watch the videos - Do the exercises</h2>
<ul>
    <li>By Deke <a href="#">McClelland</a></li>
    <li>January 2024</li>
    <li>Pages: 498</li>
    <li>ISBN 10: 0-496-91612-0 | ISBN 13: 9780492518154</li>
</ul>

<p>
    <?php echo $data['mota'] ?>
</p>

<div class="cleaner_with_height">&nbsp;</div>

<a href="index.html"><img src="images/templatemo_ads.jpg" alt="css template ad" /></a>