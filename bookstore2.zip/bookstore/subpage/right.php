<?php
        $tam= $obj->query('select * from sach order by gia desc limit 0, 4');
        $data = $tam->fetchAll();
        foreach ($data as $key => $value) 
        {
            ?>
            <div class="templatemo_product_box">
                <h1><?php echo $value['tensach'] ?></span></h1>
                <img src="images/templatemo_image_01.jpg" alt="image" />
                <div class="product_info">
                    <p>Etiam luctus. Quisque facilisis suscipit elit. Curabitur...</p>
                    <h3><?php echo number_format($value['gia']) ?> USD</h3>
                    <div class="buy_now_button"><a href="subpage.html">Buy Now</a></div>
                    <div class="detail_button"><a href="subpage.html">Detail</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            <?php
            }
         ?>

<a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>