<div id="templatemo_special_offers">
    <p>
        <span>25%</span> discounts for
        purchase over $80
    </p>
    <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
</div>


<div id="templatemo_new_books">
    <ul>
        <li>Suspen disse</li>
        <li>Maece nas metus</li>
        <li>In sed risus ac feli</li>
    </ul>
    <a href="subpage.html" style="margin-left: 50px;">Read more...</a>
</div>